Crash Nitro Sniper

https://discord.gg/z7pweUUFVe

Windows detects the exe file as a virus because it uses Discord's api to work, meaning it interferes with another program without it knowing | rep is also
provided in the Discord server so if you don't trust me you can trust them :) | Have fun sniping!